markdown-cv
===========

A curriculum vitae maintained in plain text and rendered to html and pdf using CSS.

For more details see the [project page](http://elipapa.github.io/markdown-cv) or the blog post on [why I switched to markdown for my CV](http://www.eliseopapa.org/workflow/2012/09/20/why-i-switched-to-markdown-for-my-cv/).
